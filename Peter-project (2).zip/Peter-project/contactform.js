//This page contains comments so that a future developer can know what was done.

const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Email transporter configuration
const transporter = nodemailer.createTransporter({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER, // Your Gmail
        pass: process.env.EMAIL_PASS  // Your App Password
    }
});

// Contact form endpoint - handles both detailed and simple forms
app.post('/contact', async (req, res) => {
    try {
        const {
            firstName,
            lastName,
            name,
            phone,
            email,
            address,
            city,
            postalCode,
            remodeling,
            budget,
            message,
            source
        } = req.body;

        // Determine if this is from index page (simple) or contact page (detailed)
        const isSimpleForm = !firstName && !lastName && name;
        const customerName = isSimpleForm ? name : `${firstName || ''} ${lastName || ''}`.trim();
        const formSource = source || (isSimpleForm ? 'Index Page Contact Form' : 'Contact Page Form');

        // Create email content based on form type
        let emailContent;
        
        if (isSimpleForm) {
            // Simple form from index page
            emailContent = `
                New Contact Form Submission from ${formSource}
                
                Name: ${customerName}
                Email: ${email}
                Phone: ${phone || 'Not provided'}
                
                Message: ${message || 'No message provided'}
                
                Submitted on: ${new Date().toLocaleString()}
            `;
        } else {
            // Detailed form from contact page
            emailContent = `
                New Contact Form Submission from ${formSource}
                
                Name: ${customerName}
                Email: ${email}
                Phone: ${phone || 'Not provided'}
                Address: ${address || 'Not provided'}, ${city || ''} ${postalCode || ''}
                
                Remodeling Needs: ${Array.isArray(remodeling) ? remodeling.join(', ') : remodeling || 'None specified'}
                How they heard about us: ${budget || 'Not specified'}
                
                Message: ${message || 'No additional message'}
                
                Submitted on: ${new Date().toLocaleString()}
            `;
        }

        // Email options
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: 'thegentlemenhomeimprovement@gmail.com',
            subject: `New Contact Form Submission from ${customerName} - ${formSource}`,
            text: emailContent,
            replyTo: email
        };

        // Send email
        await transporter.sendMail(mailOptions);

        res.status(200).json({ 
            success: true, 
            message: 'Message sent successfully!' 
        });

    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to send message. Please try again.' 
        });
    }
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK' });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});